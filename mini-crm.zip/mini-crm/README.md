# 🎯 LeadFlow — Mini CRM

A clean, professional **Client Lead Management System** built with Node.js + Express backend and a beautiful HTML/CSS/JS frontend.

---

## ✨ Features

- ✅ **Add / Edit / Delete** client leads
- ✅ **Status tracking** — New → Contacted → Converted
- ✅ **Live stats dashboard** with animated counters
- ✅ **Search & filter** leads instantly
- ✅ **Notes & follow-ups** per lead
- ✅ **Dark mode** professional UI
- ✅ **Toast notifications** for all actions
- ✅ **RESTful API** ready to connect to MongoDB

---

## 📁 Project Structure

```
mini-crm/
├── backend/
│   ├── server.js        ← Express API server
│   └── package.json
├── frontend/
│   └── public/
│       └── index.html   ← Full UI (served by backend)
├── package.json
└── README.md
```

---

## 🚀 Setup & Run

### 1. Install dependencies
```bash
cd backend
npm install
```

### 2. Start the server
```bash
node server.js
```

### 3. Open in browser
```
http://localhost:5000
```

---

## 🔗 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/leads` | Get all leads (supports `?status=` and `?search=`) |
| GET | `/api/leads/:id` | Get single lead |
| POST | `/api/leads` | Create new lead |
| PUT | `/api/leads/:id` | Update lead |
| DELETE | `/api/leads/:id` | Delete lead |
| GET | `/api/stats` | Get lead counts by status |

---

## 🗄️ Switching to MongoDB (Optional)

Install mongoose:
```bash
npm install mongoose
```

Replace the in-memory `leads` array in `server.js` with a Mongoose model:
```js
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/minicrm');

const Lead = mongoose.model('Lead', new mongoose.Schema({
  name: String, email: String, phone: String,
  source: String, status: String, notes: String,
}, { timestamps: true }));
```

Then swap `leads.push(...)` with `await Lead.create(...)`, etc.

---

## 🚢 Deploy to GitHub

```bash
git init
git add .
git commit -m "Initial commit — LeadFlow Mini CRM"
git remote add origin https://github.com/YOUR_USERNAME/mini-crm.git
git push -u origin main
```

---

## 🎓 Skills Demonstrated

- **Frontend**: HTML5, CSS3, Vanilla JS, REST API calls, DOM manipulation
- **Backend**: Node.js, Express.js, RESTful API design, CORS, middleware
- **Database**: In-memory (easy swap to MongoDB/MySQL)
- **Concepts**: CRUD, status workflows, search/filter, error handling

---

Made with 💜 for the internship project — Task 2: Mini CRM
