const express = require("express");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Serve frontend static files
app.use(express.static(path.join(__dirname, "../frontend/public")));

// ─── In-Memory Database (swap with MongoDB easily) ───────────────────────────
let leads = [
  {
    id: uuidv4(),
    name: "Priya Sharma",
    email: "priya@example.com",
    phone: "9876543210",
    source: "Website",
    status: "new",
    notes: "Interested in web development services.",
    createdAt: new Date("2026-03-20").toISOString(),
  },
  {
    id: uuidv4(),
    name: "Rahul Mehta",
    email: "rahul@startup.io",
    phone: "9123456780",
    source: "Referral",
    status: "contacted",
    notes: "Called on Monday. Needs a follow-up by Friday.",
    createdAt: new Date("2026-03-22").toISOString(),
  },
  {
    id: uuidv4(),
    name: "Anjali Verma",
    email: "anjali@corp.com",
    phone: "9988776655",
    source: "Social Media",
    status: "converted",
    notes: "Signed contract for CRM project.",
    createdAt: new Date("2026-03-24").toISOString(),
  },
];

// ─── ROUTES ──────────────────────────────────────────────────────────────────

// GET all leads (with optional search/filter)
app.get("/api/leads", (req, res) => {
  let result = [...leads];
  const { status, search } = req.query;

  if (status && status !== "all") {
    result = result.filter((l) => l.status === status);
  }
  if (search) {
    const q = search.toLowerCase();
    result = result.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.email.toLowerCase().includes(q) ||
        l.source.toLowerCase().includes(q)
    );
  }

  res.json({ success: true, data: result, total: result.length });
});

// GET single lead
app.get("/api/leads/:id", (req, res) => {
  const lead = leads.find((l) => l.id === req.params.id);
  if (!lead) return res.status(404).json({ success: false, message: "Lead not found" });
  res.json({ success: true, data: lead });
});

// POST create lead
app.post("/api/leads", (req, res) => {
  const { name, email, phone, source, status, notes } = req.body;
  if (!name || !email) {
    return res.status(400).json({ success: false, message: "Name and email are required" });
  }
  const newLead = {
    id: uuidv4(),
    name,
    email,
    phone: phone || "",
    source: source || "Website",
    status: status || "new",
    notes: notes || "",
    createdAt: new Date().toISOString(),
  };
  leads.unshift(newLead);
  res.status(201).json({ success: true, data: newLead, message: "Lead created!" });
});

// PUT update lead
app.put("/api/leads/:id", (req, res) => {
  const index = leads.findIndex((l) => l.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, message: "Lead not found" });

  leads[index] = { ...leads[index], ...req.body, id: leads[index].id };
  res.json({ success: true, data: leads[index], message: "Lead updated!" });
});

// DELETE lead
app.delete("/api/leads/:id", (req, res) => {
  const index = leads.findIndex((l) => l.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, message: "Lead not found" });
  leads.splice(index, 1);
  res.json({ success: true, message: "Lead deleted!" });
});

// GET stats
app.get("/api/stats", (req, res) => {
  res.json({
    success: true,
    data: {
      total: leads.length,
      new: leads.filter((l) => l.status === "new").length,
      contacted: leads.filter((l) => l.status === "contacted").length,
      converted: leads.filter((l) => l.status === "converted").length,
    },
  });
});

// Fallback to frontend
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/public/index.html"));
});

app.listen(PORT, () => {
  console.log(`\n🚀 Mini CRM Server running at http://localhost:${PORT}\n`);
});
